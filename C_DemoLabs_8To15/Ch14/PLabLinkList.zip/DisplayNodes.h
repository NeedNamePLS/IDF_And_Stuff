#ifndef DisplayNodes
#define DisplayNodes

void displayAllStudents(node_t*n);
void displayOneEach(node_t*n, int choice);
void displayOneStudent(node_t*n);
int clear_Input();

#endif